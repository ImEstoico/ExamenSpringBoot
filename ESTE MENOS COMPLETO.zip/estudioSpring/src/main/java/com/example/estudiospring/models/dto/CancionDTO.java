package com.example.estudiospring.models.dto;

import com.example.estudiospring.repositories.entity.CancionEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@AllArgsConstructor // esto da constuctor lleno
@NoArgsConstructor // esto da constuctor vacio
public class CancionDTO {

    private Long id;
    private String titulo;
    private String genero;
    private int duracionSegundos;




    //Convertidores dto/entitiy

    public static CancionDTO convertToDTO(CancionEntity entity){
        CancionDTO dto = new CancionDTO();
        dto.setId(entity.getId());
        dto.setTitulo(entity.getTitulo());
        dto.setGenero(entity.getGenero());
        dto.setDuracionSegundos(entity.getDuracionSegundos());
        return dto;
    }

    public static CancionEntity convertToEntity(CancionDTO dto){
        CancionEntity entity = new CancionEntity();
        entity.setId(dto.getId());
        entity.setTitulo(dto.getTitulo());
        entity.setGenero(dto.getGenero());
        entity.setDuracionSegundos(dto.getDuracionSegundos());
        return entity;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CancionDTO that = (CancionDTO) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
