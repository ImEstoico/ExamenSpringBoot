package com.example.estudiospring.repositories.dao;

import com.example.estudiospring.repositories.entity.CancionEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CancionRepository {
    List<CancionEntity> findAll();
    CancionEntity findById (CancionEntity cancionEntity);
    void save(CancionEntity cancionEntity);
    void delete (CancionEntity cancionEntity);
}
