package com.example.estudiospring.services;

import com.example.estudiospring.models.dto.CancionDTO;
import com.example.estudiospring.repositories.dao.CancionRepository;
import com.example.estudiospring.repositories.entity.CancionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

// @Service le dice a Spring Boot: "Esta clase es la capa de Servicio (el intermediario/traductor).
// Gestiónala tú para poder inyectarla con @Autowired dentro del Controlador".
@Service
public class CancionServiceImpl implements CancionService {

    // @Autowired conecta automáticamente este Servicio con el Repositorio (el almacén)
    // sin que tengamos que hacer un "new CancionRepositoryImpl()".
    @Autowired
    private CancionRepository cancionRepository;

    // --- 1. PEDIR TODAS LAS CANCIONES Y TRADUCIRLAS A DTO ---
    @Override
    public List<CancionDTO> findAll() {
        // 1. Le pedimos al almacén (Repositorio) la lista original de Entities
        List<CancionEntity> listaEntities = cancionRepository.findAll();

        // 2. Creamos una lista nueva y vacía donde iremos guardando los DTOs ya traducidos
        List<CancionDTO> listaDTOs = new ArrayList<>();

        // 3. Recorremos la lista de Entities desde el cajón 0 hasta el último (.size())
        for (int i = 0; i < listaEntities.size(); i++) {
            // Sacamos la Entity que está en la posición 'i'
            CancionEntity entity = listaEntities.get(i);

            // La traducimos de Entity a DTO usando el méto do estático de CancionDTO
            CancionDTO dto = CancionDTO.convertToDTO(entity);

            // Metemos ese DTO traducido dentro de nuestra lista nueva
            listaDTOs.add(dto);
        }

        // 4. Devolvemos la lista llena de DTOs al Controlador
        return listaDTOs;
    }

    // --- 2. BUSCAR UNA CANCIÓN POR SU ID ---
    @Override
    public CancionDTO findById(CancionDTO cancionDTO) {
        // 1. El Controlador nos pasa un DTO (que solo lleva el ID).
        // Lo traducimos a Entity porque el almacén solo entiende de Entities.
        CancionEntity cancionBuscar = CancionDTO.convertToEntity(cancionDTO);

        // 2. Le pedimos al almacén que busque esa Entity por su ID
        CancionEntity cancionEncontrada = cancionRepository.findById(cancionBuscar);

        // 3. Si el almacén la ha encontrado (no es null)...
        if (cancionEncontrada != null) {
            // ...la volvemos a traducir de Entity a DTO y se la devolvemos al Controlador
            return CancionDTO.convertToDTO(cancionEncontrada);
        }

        // Si no existía en el almacén, devolvemos null
        return null;
    }

    // --- 3. GUARDAR O ACTUALIZAR UNA CANCIÓN ---
    @Override
    public void save(CancionDTO cancionDTO) {
        // 1. Traducimos el DTO que viene del formulario a una Entity
        CancionEntity entity = CancionDTO.convertToEntity(cancionDTO);

        // 2. Se la pasamos al almacén para que la guarde (o la actualice si ya tenía ID)
        cancionRepository.save(entity);
    }

    // --- 4. BORRAR UNA CANCIÓN ---
    @Override
    public void delete(CancionDTO cancionDTO) {
        // 1. Traducimos el DTO con el ID que queremos borrar a una Entity
        CancionEntity entity = CancionDTO.convertToEntity(cancionDTO);

        // 2. Le decimos al almacén que la elimine de la lista
        cancionRepository.delete(entity);
    }
}