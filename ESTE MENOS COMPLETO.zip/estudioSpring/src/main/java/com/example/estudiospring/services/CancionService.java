package com.example.estudiospring.services;

import com.example.estudiospring.models.dto.CancionDTO;
import java.util.List;

public interface CancionService{

    List<CancionDTO> findAll();
    CancionDTO findById (CancionDTO cancionDTO);
    void save(CancionDTO cancionDTO);
    void delete (CancionDTO cancionDTO);
}
