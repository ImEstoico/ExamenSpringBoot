package com.example.estudiospring.repositories.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@AllArgsConstructor // esto da constuctor lleno
@NoArgsConstructor // esto da constuctor vacio
public class CancionEntity {

    private Long id;
    private String titulo;
    private String genero;
    private int duracionSegundos;

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CancionEntity entity = (CancionEntity) o;
        return Objects.equals(id, entity.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}