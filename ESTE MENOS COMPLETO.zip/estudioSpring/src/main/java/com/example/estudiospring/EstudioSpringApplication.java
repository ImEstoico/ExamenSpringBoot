package com.example.estudiospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudioSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(EstudioSpringApplication.class, args);
    }

}
