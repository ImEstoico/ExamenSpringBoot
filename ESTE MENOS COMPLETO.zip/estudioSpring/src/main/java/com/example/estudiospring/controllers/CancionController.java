package com.example.estudiospring.controllers;

import com.example.estudiospring.models.dto.CancionDTO;
import com.example.estudiospring.services.CancionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

// @Controller le dice a Spring Boot: "Esta clase es el camarero web: escucha las URLs del navegador y devuelve páginas HTML".
@Controller
public class CancionController {

    // @Autowired conecta automáticamente el Controlador con el Servicio (el Chef) sin tener que hacer "new CancionServiceImpl()".
    @Autowired
    private CancionService cancionService;

    // --- 1. LISTAR TODAS LAS CANCIONES (TABLA PRINCIPAL) ---
    // Se ejecuta cuando escribes en el navegador: http://localhost:8080/canciones
    @GetMapping("/canciones")
    public ModelAndView findAll() {
        // 1. Creamos la bandeja (ModelAndView) y le decimos que abra el archivo "canciones.html"
        ModelAndView mav = new ModelAndView("canciones");

        // 2. Le pedimos al Servicio la lista con todas las canciones (en formato DTO)
        List<CancionDTO> listaCanciones = cancionService.findAll();

        // 3. Metemos la lista en la bandeja con la etiqueta "listaCanciones".
        // Ese nombre entre comillas es el que usas en canciones.html -> th:each="cancion : ${listaCanciones}"
        mav.addObject("listaCanciones", listaCanciones);

        // 4. Entregamos la bandeja (HTML + datos) al navegador
        return mav;
    }

    // --- 2. BORRAR UNA CANCIÓN ---
    // Se ejecuta al pulsar el enlace "Borrar", que va a: /canciones/delete/1 (o el ID que sea)
    @GetMapping("/canciones/delete/{idCancion}")
    public ModelAndView delete(@PathVariable("idCancion") Long idCancion) {
        // @PathVariable captura el número que viene al final de la URL ({idCancion}) y lo guarda en la variable idCancion.

        // 1. Como el Servicio pide un objeto CancionDTO entero (no un número suelto), creamos un DTO vacío y le metemos solo el ID
        CancionDTO cancionBorrar = new CancionDTO();
        cancionBorrar.setId(idCancion);

        // 2. Le decimos al Servicio que borre la canción que tenga ese ID
        cancionService.delete(cancionBorrar);

        // 3. "redirect:/canciones" le dice al navegador que recargue la ruta "/canciones" para ver la tabla ya sin esa canción
        return new ModelAndView("redirect:/canciones");
    }

    // --- 3. VER EL DETALLE DE UNA SOLA CANCIÓN ---
    // Se ejecuta al pulsar el enlace "Ver", que va a: /canciones/1 (o el ID que sea)
    @GetMapping("/canciones/{idCancion}")
    public ModelAndView findByID(@PathVariable("idCancion") Long idCancion) {
        // 1. Creamos un DTO vacío y le metemos el ID que hemos capturado de la URL con @PathVariable
        CancionDTO cancionBuscar = new CancionDTO();
        cancionBuscar.setId(idCancion);

        // 2. Le pedimos al Servicio que nos busque la canción completa (con su título, género y duración)
        CancionDTO cancionEncontrada = cancionService.findById(cancionBuscar);

        // 3. Creamos la bandeja diciendo que vamos a mostrar el archivo "cancionshow.html"
        ModelAndView mav = new ModelAndView("cancionshow");

        // 4. Metemos la canción encontrada con la etiqueta "cancion".
        // Así en cancionshow.html puedes poner ${cancion.titulo}, ${cancion.genero}, etc.
        mav.addObject("cancion", cancionEncontrada);

        return mav;
    }

    // --- 4. ABRIR EL FORMULARIO VACÍO PARA CREAR UNA CANCIÓN NUEVA ---
    // Se ejecuta al pulsar "Añadir nueva canción", que va a: /canciones/add
    @GetMapping("/canciones/add")
    public ModelAndView add() {
        // 1. Le decimos que abra la página del formulario: "cancionform.html"
        ModelAndView mav = new ModelAndView("cancionform");

        // 2. Le mandamos un CancionDTO() totalmente vacío con la etiqueta "cancion".
        // El formulario necesita este objeto vacío (th:object="${cancion}") para que el usuario rellene sus huecos.
        mav.addObject("cancion", new CancionDTO());

        return mav;
    }

    // --- 5. GUARDAR LOS DATOS DEL FORMULARIO (SIRVE TANTO PARA CREAR COMO PARA EDITAR) ---
    // Se ejecuta cuando pulsas el botón "Guardar" (submit) dentro de cancionform.html
    // Usa @PostMapping porque el formulario HTML tiene method="post" y th:action="@{/canciones/save}"
    @PostMapping("/canciones/save")
    public ModelAndView save(@ModelAttribute("cancion") CancionDTO cancionDTO) {
        // @ModelAttribute("cancion") recoge el objeto que el usuario ha rellenado en el formulario (con todos sus inputs)
        // y lo mete automáticamente dentro de la variable cancionDTO.

        // 1. Se lo pasamos al Servicio para que lo guarde (si el ID viene vacío creará una nueva; si trae ID, actualizará la existente)
        cancionService.save(cancionDTO);

        // 2. Volvemos a recargar la tabla principal "/canciones" para ver los cambios
        return new ModelAndView("redirect:/canciones");
    }

    // --- 6. ABRIR EL FORMULARIO RELLENO PARA EDITAR UNA CANCIÓN ---
    // Se ejecuta al pulsar el enlace "Editar", que va a: /canciones/update/1
    @GetMapping("/canciones/update/{idCancion}")
    public ModelAndView update(@PathVariable("idCancion") Long idCancion) {
        // 1. Igual que en findById: metemos el ID de la URL en un DTO y le pedimos al Servicio la canción completa
        CancionDTO cancionBuscar = new CancionDTO();
        cancionBuscar.setId(idCancion);
        CancionDTO cancionEncontrada = cancionService.findById(cancionBuscar);

        // 2. Abrimos EXACTAMENTE EL MISMO formulario ("cancionform.html") que usamos en add()
        ModelAndView mav = new ModelAndView("cancionform");

        // 3. LA DIFERENCIA CON ADD(): En vez de pasarle un new CancionDTO() vacío, le pasamos la "cancionEncontrada".
        // Así las cajas de texto del formulario aparecen ya rellenas con el título, género, duración y su ID oculto.
        mav.addObject("cancion", cancionEncontrada);

        return mav;
    }
}