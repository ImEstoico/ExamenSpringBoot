package com.example.estudiospring.repositories.dao;

import com.example.estudiospring.repositories.entity.CancionEntity;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

// @Repository le dice a Spring Boot: "Esta clase es el almacén de datos, gestiónala tú para poder inyectarla con @Autowired en el Service"
@Repository
public class CancionRepositoryImpl implements CancionRepository {

    // Nuestra "base de datos" falsa en memoria.
    // Es static para que sea una única lista compartida y no se borre en cada petición.
    private static List<CancionEntity> datos = new ArrayList<>();

    // --- 1. DEVOLVER TODAS LAS CANCIONES ---
    @Override
    public List<CancionEntity> findAll() {
        // Devuelve directamente la lista completa con todas las canciones que haya guardadas
        return datos;
    }

    // --- 2. BUSCAR UNA CANCIÓN POR SU ID ---
    @Override
    public CancionEntity findById(CancionEntity cancionEntity) {
        // indexOf busca en qué cajón (0, 1, 2...) de la lista está la canción con ese mismo ID (usa el equals por ID).
        // Si NO existe en la lista, indexOf devuelve siempre -1.
        int posicion = datos.indexOf(cancionEntity);

        // Si la posición es 0 o mayor, significa que sí la ha encontrado
        if (posicion >= 0) {
            // Sacamos y devolvemos la canción completa que está en ese cajón
            return datos.get(posicion);
        }
        // Si era -1 (no existía), devolvemos null
        return null;
    }

    // --- 3. GUARDAR (CREAR NUEVA O ACTUALIZAR EXISTENTE) ---
    @Override
    public void save(CancionEntity cancionEntity) {
        // Comprobamos dos cosas: ¿Trae ya un ID relleno? Y además, ¿existe ya en nuestra lista?
        if (cancionEntity.getId() != null && findById(cancionEntity) != null) {
            // --- MODO EDITAR (UPDATE) ---
            // 1. Buscamos en qué posición de la lista está la canción antigua
            int posicion = datos.indexOf(cancionEntity);
            // 2. .set() machaca la canción antigua de esa posición con los datos nuevos editados
            datos.set(posicion, cancionEntity);
        } else {
            // --- MODO CREAR NUEVA (INSERT) ---
            // 1. Calculamos el nuevo ID con un operador ternario (? :):
            //    - Si la lista está vacía (datos.isEmpty()), le ponemos el ID 1 (1L).
            //    - Si ya tiene canciones, miramos la última canción de la lista (datos.size() - 1), cogemos su ID y le sumamos 1.
            Long id = datos.isEmpty() ? 1L : datos.get(datos.size() - 1).getId() + 1;

            // 2. Le asignamos ese ID nuevo a la canción que vamos a guardar
            cancionEntity.setId(id);

            // 3. La añadimos al final de la lista
            datos.add(cancionEntity);
        }
    }

    // --- 4. BORRAR UNA CANCIÓN ---
    @Override
    public void delete(CancionEntity cancionEntity) {
        // Buscamos en qué posición de la lista está la canción que queremos borrar (comparando por ID)
        int posicion = datos.indexOf(cancionEntity);

        // Si la ha encontrado (posición 0 o mayor)...
        if (posicion >= 0) {
            // .remove() la elimina de la lista
            datos.remove(posicion);
        }
    }

    // --- 5. BLOQUE ESTÁTICO (DATOS DE PRUEBA INICIALES) ---
    // Este bloque static { ... } se ejecuta automáticamente UNA SOLA VEZ al arrancar el programa.
    // Sirve para meter las 5 canciones iniciales en la lista "datos" y no empezar con la tabla vacía.
    static {
        CancionEntity c1 = new CancionEntity();
        // Como al principio datos.size() es 0, 0 + 1 = ID 1
        c1.setId(Long.valueOf(datos.size() + 1));
        c1.setTitulo("Monte de los aullidos");
        c1.setGenero("Rock");
        c1.setDuracionSegundos(400);
        datos.add(c1); // Ahora datos.size() pasa a ser 1

        CancionEntity c2 = new CancionEntity();
        // Como datos.size() ahora es 1, 1 + 1 = ID 2 (y así sucesivamente con las demás)
        c2.setId(Long.valueOf(datos.size() + 1));
        c2.setTitulo("La chispa adecuada");
        c2.setGenero("Rock");
        c2.setDuracionSegundos(328);
        datos.add(c2);

        CancionEntity c3 = new CancionEntity();
        c3.setId(Long.valueOf(datos.size() + 1));
        c3.setTitulo("Soldadito marinero");
        c3.setGenero("Rock");
        c3.setDuracionSegundos(254);
        datos.add(c3);

        CancionEntity c4 = new CancionEntity();
        c4.setId(Long.valueOf(datos.size() + 1));
        c4.setTitulo("Blinding Lights");
        c4.setGenero("Pop");
        c4.setDuracionSegundos(200);
        datos.add(c4);

        CancionEntity c5 = new CancionEntity();
        c5.setId(Long.valueOf(datos.size() + 1));
        c5.setTitulo("Lose Yourself");
        c5.setGenero("Rap");
        c5.setDuracionSegundos(326);
        datos.add(c5);
    }
}